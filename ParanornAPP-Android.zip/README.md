# ParanornAPP

Aplicativo Android que abre diretamente a página de Campanhas do C.R.I.S.

URL inicial:
https://crisordemparanormal.com/campanhas

## Compilar
Abra esta pasta no Android Studio e aguarde o Gradle sincronizar.
Depois use Build > Build APK(s).

O APK de debug será gerado em:
app/build/outputs/apk/debug/app-debug.apk
